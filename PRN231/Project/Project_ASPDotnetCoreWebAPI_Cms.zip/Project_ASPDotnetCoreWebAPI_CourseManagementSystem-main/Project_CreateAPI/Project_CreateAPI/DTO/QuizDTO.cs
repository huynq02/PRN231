﻿namespace Project_CreateAPI.DTO
{
    public class QuizDTO
    {
        public int QuizId { get; set; }
        public int CourseId { get; set; }
        public string? Title { get; set; }
    }
}
