using AutoMapper;
using BusinessObjects.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;

namespace eBookStoreWeb.Pages.Author
{
    [Authorize(Roles = "admin")]
    public class UpdateModel : PageModel
    {

        [BindProperty]
        public BusinessObjects.Dtos.AuthorDto AuthorModel { get; set; }

        public async Task<IActionResult> OnGet(int authorId)
        {
            var client = new Services(HttpContext);
            var author = await client.Get<OdataList<BusinessObjects.Dtos.AuthorDto>>($"/odata/authors?filter=authorId eq {authorId}");
            if (author == null) return NotFound();

            AuthorModel = author.Value.FirstOrDefault();
            return Page();
        }

        public async Task<IActionResult> OnPost()
        {
            if(!ModelState.IsValid)
            {
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Put($"/odata/authors/{AuthorModel.AuthorId}", AuthorModel);
            if (result == null) return NotFound();

            return RedirectToPage("/Author/Details", new { AuthorModel.AuthorId });
        }
    }
}
