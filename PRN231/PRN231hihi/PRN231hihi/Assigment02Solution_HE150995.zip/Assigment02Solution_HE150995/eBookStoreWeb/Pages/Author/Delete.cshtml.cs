using BusinessObjects.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Data;

namespace eBookStoreWeb.Pages.Author
{
    [Authorize(Roles = "admin")]
    public class DeleteModel : PageModel
    {
        public async Task<IActionResult> OnPost(int authorId)
        {
            var client = new Services(HttpContext);
            var result = await client.Delete($"/odata/authors/{authorId}");
            if (result == null) return NotFound();

            return RedirectToPage("/Author/Index"); ;
        }
    }
}
