using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using BusinessObjects.Models;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace eBookStoreWeb.Pages.Author
{
    [Authorize]
    public class IndexModel : PageModel
    {
        public List<BusinessObjects.Models.Author> Authors { get; set; }

        public async Task<IActionResult> OnGet()
        {
            var _service = new Services(HttpContext);
            var authors = await _service.Get<OdataList<BusinessObjects.Models.Author>>("/odata/Authors");
            if(authors == null)
            {
                return NotFound();
            }
            Authors = authors.Value.ToList();
            return Page();
        }

    }
}
