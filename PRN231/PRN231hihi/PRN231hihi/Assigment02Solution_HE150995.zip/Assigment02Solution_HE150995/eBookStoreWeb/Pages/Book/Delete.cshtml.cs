using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Book
{
    [Authorize(Roles = "admin")]
    public class DeleteModel : PageModel
    {
        public async Task<IActionResult> OnPost(int BookId)
        {
            var client = new Services(HttpContext);
            var result = await client.Delete($"/odata/Books/{BookId}");
            if (result == null) return NotFound();

            return RedirectToPage("/Book/Index"); ;
        }
    }
}
