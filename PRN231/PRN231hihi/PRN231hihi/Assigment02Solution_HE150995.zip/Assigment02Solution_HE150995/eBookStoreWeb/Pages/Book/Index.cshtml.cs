using BusinessObjects.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;

namespace eBookStoreWeb.Pages.Book
{
    public class IndexModel : PageModel
    {
        public List<BusinessObjects.Models.Book> Books { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? TitleSearch { get; set; }

        [BindProperty(SupportsGet = true)]
        public int? minPrice { get; set; }
        [BindProperty(SupportsGet = true)]
        public int? maxPrice { get; set; }

        public async Task<IActionResult> OnGet()
        {
            var _service = new Services(HttpContext);
            var conditionSearchs = new List<string>();
            if(TitleSearch!= null)
            {
                conditionSearchs.Add($"contains(Title, '{TitleSearch}')");
            }
            if (minPrice != null)
            {
                conditionSearchs.Add($"Price ge {minPrice}");
            }
            if (maxPrice != null)
            {
                conditionSearchs.Add($"Price le {maxPrice}");
            }
            var url = "/odata/Books";
            if(conditionSearchs.Count > 0) url += $"?$filter={string.Join(" and ", conditionSearchs)}";
            var result = await _service.Get<OdataList<BusinessObjects.Models.Book>>(url);
            if (result == null)
            {
                return NotFound();
            }
            Books = result.Value.ToList();
            List<BusinessObjects.Models.Publisher> listPublisher = await GetPublishers();
            ViewData["ListPublisher"] = listPublisher;
            return Page();
        }

        public async Task<List<BusinessObjects.Models.Publisher>> GetPublishers()
        {
            var _service = new Services(HttpContext);
            var result = await _service.Get<OdataList<BusinessObjects.Models.Publisher>>("/odata/Publishers");
            List<BusinessObjects.Models.Publisher> publishers = new List<BusinessObjects.Models.Publisher>();
            if (result != null)
            {
                publishers = result.Value.ToList();
            }
            return publishers;
        }

    }
}
