using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Book
{
    [Authorize(Roles = "admin")]
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public BusinessObjects.Dtos.BookDto BookModel { get; set; }

        public async Task<IActionResult> OnGet(int BookId)
        {
            var client = new Services(HttpContext);
            var Book = await client.Get<OdataList<BusinessObjects.Dtos.BookDto>>($"/odata/Books?filter=BookId eq {BookId}");
            if (Book == null) return NotFound();

            BookModel = Book.Value.FirstOrDefault();
            ViewData["ListPublisher"] = await GetPublishers();
            return Page();
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                ViewData["ListPublisher"] = await GetPublishers();
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Put($"/odata/Books/{BookModel.BookId}", BookModel);
            if (result == null) return NotFound();

            return RedirectToPage("/Book/Details", new { BookModel.BookId });
        }

        public async Task<List<BusinessObjects.Models.Publisher>> GetPublishers()
        {
            var _service = new Services(HttpContext);
            var result = await _service.Get<OdataList<BusinessObjects.Models.Publisher>>("/odata/Publishers");
            List<BusinessObjects.Models.Publisher> publishers = new List<BusinessObjects.Models.Publisher>();
            if (result != null)
            {
                publishers = result.Value.ToList();
            }
            return publishers;
        }
    }
}

