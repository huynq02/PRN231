using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Publisher
{
    [Authorize(Roles = "admin")]
    public class DeleteModel : PageModel
    {
        public async Task<IActionResult> OnPost(int pubId)
        {
            var client = new Services(HttpContext);
            var result = await client.Delete($"/odata/publishers/{pubId}");
            if (result == null) return NotFound();

            return RedirectToPage("/Publisher/Index"); ;
        }
    }
}
