using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Publisher
{
    [Authorize]
    public class IndexModel : PageModel
    {
        public List<BusinessObjects.Models.Publisher> Publishers { get; set; }

        public async Task<IActionResult> OnGet()
        {
            var _service = new Services(HttpContext);
            var publishers = await _service.Get<OdataList<BusinessObjects.Models.Publisher>>("/odata/Publishers");
            if (publishers == null)
            {
                return NotFound();
            }
            Publishers = publishers.Value.ToList();
            return Page();
        }
    }
}
