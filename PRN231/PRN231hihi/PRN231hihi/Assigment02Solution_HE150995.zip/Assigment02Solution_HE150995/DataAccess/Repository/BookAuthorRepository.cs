﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Repository
{
    public class BookAuthorRepository : IBookAuthorRepository
    {
        public void DeleteBookAuthor(BookAuthor bookAuthor)
        {
            BookAuthorDAO.DeleteBookAuthor(bookAuthor);
        }

        //public List<BookAuthor> FindBookAuthorByAuthorId(int bookId)
        //{
        //    throw new NotImplementedException();
        //}

        //public List<BookAuthor> FindBookAuthorByBookId(int bookId)
        //{
        //    throw new NotImplementedException();
        //}

        public BookAuthor FindBookAuthorById(int bookId, int authorId)
        {
            return BookAuthorDAO.FindBookAuthorById(bookId, authorId);
        }

        public List<BookAuthor> GetBookAuthors()
        {
            return BookAuthorDAO.GetBookAuthors();

        }

        public void SaveBookAuthor(BookAuthor bookAuthor)
        {
            BookAuthorDAO.SaveBookAuthor(bookAuthor);   
        }

        public void UpdateBookAuthor(BookAuthor bookAuthor)
        {
            BookAuthorDAO.UpdateBookAuthor(bookAuthor);
        }
    }
}
