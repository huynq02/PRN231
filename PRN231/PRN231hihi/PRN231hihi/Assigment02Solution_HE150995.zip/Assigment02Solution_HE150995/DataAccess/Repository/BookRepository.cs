﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class BookRepository : IBookRepository
    {
        public void DeleteBook(Book book) => BookDAO.DeleteBook(book);

        public Book FindBookById(int id) => BookDAO.FindBookById(id);

        public List<Book> GetBooks() => BookDAO.GetBooks();

        public void SaveBook(Book book) => BookDAO.SaveBook(book);

        public void UpdateBook(Book book) => BookDAO.UpdateBook(book);
    }
}
