﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System.Collections.Generic;

namespace DataAccess.Repositories
{

    public class AuthorRepository : IAuthorRepository
    {
        public void DeleteAuthor( Author author) => AuthorDAO.DeleteAuthor(author);

        public Author FindAuthorById( int id) => AuthorDAO.FindAuthorById(id);

        public List<Author> GetAuthors() => AuthorDAO.GetAuthors();

        public void SaveAuthor( Author author) => AuthorDAO.SaveAuthor(author);

        public void UpdateAuthor( Author author) => AuthorDAO.UpdateAuthor(author);
    }
}
