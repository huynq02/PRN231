﻿using BusinessObjects.Models;
using System.Collections.Generic;

namespace DataAccess.IRepository
{
    public interface IUserRepository
    {
        void DeleteUser( User user);
        Task<User?> FindUserById( int id);
        List<User> GetUsers();
        void SaveUser( User user);
        void UpdateUser( User user);
        Task<User?> Login( string emailAddress, string password);
    }

}
