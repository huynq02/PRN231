﻿using BusinessObjects.Models;
using System.Collections.Generic;

namespace DataAccess.IRepository
{
    public interface IRoleRepository
    {
        void DeleteRole(  Role role);
        Role FindRoleById(  int id);
        List<Role> GetRoles();
        void SaveRole(  Role role);
        void UpdateRole(  Role role);
    }
}
