﻿using BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.IRepository
{
    public interface IBookAuthorRepository
    {
        void DeleteBookAuthor(BookAuthor bookAuthor);
        BookAuthor FindBookAuthorById(int bookId, int authorId);
        //List<BookAuthor> FindBookAuthorByBookId(int bookId);
        //List<BookAuthor> FindBookAuthorByAuthorId(int bookId);
        List<BookAuthor> GetBookAuthors();
        void SaveBookAuthor(BookAuthor bookAuthor);
        void UpdateBookAuthor(BookAuthor bookAuthor);
    }
}
