﻿using BusinessObjects.Models;
using System.Collections.Generic;

namespace DataAccess.IRepository
{
    public interface IBookRepository
    {
        void DeleteBook( Book book);
        Book FindBookById( int id);
        List<Book> GetBooks();
        void SaveBook( Book book);
        void UpdateBook( Book book);
    }
}
