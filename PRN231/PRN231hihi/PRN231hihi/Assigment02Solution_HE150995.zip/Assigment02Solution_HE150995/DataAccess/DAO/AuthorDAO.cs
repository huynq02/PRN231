﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.DAO
{
    public class AuthorDAO
    {
        private static AuthorDAO instance = null;
        private static readonly object instanceLock = new object();

        public static AuthorDAO Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new AuthorDAO();
                    }
                }
                return instance;
            }
        }

        public static List<Author> GetAuthors()
        {
            List<Author> authors;
            try
            {
                var context = new BookStoreContext();

                authors = context.Authors.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return authors;
        }

        public static Author FindAuthorById(int id)
        {
            var author = new Author();
            try
            {
                var context = new BookStoreContext();

                author = context.Authors.AsNoTracking().FirstOrDefault(e => e.AuthorId == id);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return author;
        }

        public static void SaveAuthor(Author author)
        {
            try
            {
                var context = new BookStoreContext();

                context.Authors.Add(author);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdateAuthor(Author author)
        {
            try
            {
                var context = new BookStoreContext();

                context.Entry(author).State = EntityState.Modified;
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteAuthor(Author author)
        {
            try
            {
                var context = new BookStoreContext();

                var c = context.Authors.AsNoTracking().SingleOrDefault(e => e.AuthorId.Equals(author.AuthorId));
                if (c != null)
                {
                    context.Authors.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
