﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.DAO
{
    public class BookAuthorDAO
    {
        private static BookAuthorDAO _instance = null;
        private static readonly object _instanceLock = new();

        public static BookAuthorDAO Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {
                        _instance = new BookAuthorDAO();
                    }
                }
                return _instance;
            }
        }

        public static List<BookAuthor> GetBookAuthors()
        {
            List<BookAuthor> bookAuthors;
            try
            {
                var context = new BookStoreContext();

                bookAuthors = context.BookAuthors.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return bookAuthors;
        }

        public static BookAuthor FindBookAuthorById(int authorId, int bookId)
        {
            var bookAuthor = new BookAuthor();
            try
            {
                var context = new BookStoreContext();

                bookAuthor = context.BookAuthors.AsNoTracking().FirstOrDefault(e => e.AuthorId == authorId && e.BookId == bookId);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return bookAuthor;
        }

        public static void SaveBookAuthor(BookAuthor bookAuthor)
        {
            try
            {
                var context = new BookStoreContext();

                context.BookAuthors.Add(bookAuthor);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdateBookAuthor(BookAuthor bookAuthor)
        {
            try
            {
                var context = new BookStoreContext();

                context.Entry(bookAuthor).State = EntityState.Modified;
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteBookAuthor(BookAuthor bookAuthor)
        {
            try
            {
                var context = new BookStoreContext();

                var c = context.BookAuthors.SingleOrDefault(e => e.AuthorId.Equals(bookAuthor.AuthorId) && e.BookId.Equals(bookAuthor.BookId));
                if (c != null)
                {
                    context.BookAuthors.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
