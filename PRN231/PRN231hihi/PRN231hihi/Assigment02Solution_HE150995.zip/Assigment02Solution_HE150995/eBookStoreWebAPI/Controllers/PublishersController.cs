﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using BusinessObjects.Models;
using BusinessObjects.Dtos;
using DataAccess.IRepository;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Formatter;
using AutoMapper;
using DataAccess.Repositories;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace ePublisherStoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PublishersController : ODataController
    {
        private readonly BookStoreContext _dbContext;
        private readonly IPublisherRepository _publisherRepository;
        private readonly IMapper _mapper;

        public PublishersController(BookStoreContext dbContext, IPublisherRepository publisherRepository, IMapper mapper)
        {
            _dbContext = dbContext;
            _publisherRepository = publisherRepository;
            dbContext.ChangeTracker.QueryTrackingBehavior = Microsoft.EntityFrameworkCore.QueryTrackingBehavior.NoTracking;
            _mapper = mapper;
        }

        [HttpGet]
        [EnableQuery(PageSize = 10)]
        [Authorize]
        public IActionResult GetPublishers()
        {
            var Publishers = _publisherRepository.GetPublishers();
            return Ok(Publishers);
        }

        [HttpGet("{key}")]
        [EnableQuery]
        [Authorize]
        public IActionResult GetPublisherById([FromODataUri] int key)
        {
            return Ok(_publisherRepository.FindPublisherById(key));
        }

        [HttpPost]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Post([FromBody] PublisherDto PublisherDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var Publisher = _mapper.Map<Publisher>(PublisherDto);
            _publisherRepository.SavePublisher(Publisher);
            return Created(Publisher);
        }
        [HttpPut("{key}")]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Put([FromODataUri] int key, [FromBody] PublisherDto PublisherDto)
        {
            var existedPublisher = _publisherRepository.FindPublisherById(key);
            if (existedPublisher == null)
            {
                return NotFound();
            }
            var Publisher = _mapper.Map<Publisher>(PublisherDto);
            Publisher.PubId = existedPublisher.PubId;
            _publisherRepository.UpdatePublisher(Publisher);
            return Ok();
        }

        [HttpDelete("{key}")]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Delete([FromODataUri] int key)
        {
            var Publisher = _publisherRepository.FindPublisherById(key);
            if (Publisher == null)
            {
                return NotFound();
            }
            _publisherRepository.DeletePublisher(Publisher);
            return Ok();
        }
    }
}
