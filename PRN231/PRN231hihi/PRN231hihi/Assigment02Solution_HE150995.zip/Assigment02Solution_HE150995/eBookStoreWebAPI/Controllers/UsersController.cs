﻿using AutoMapper;
using BusinessObjects.Dtos;
using BusinessObjects.Models;
using DataAccess.IRepository;
using DataAccess.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;

namespace eBookStoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ODataController
    {
        private readonly BookStoreContext _dbContext;
        private readonly IUserRepository _userRepository;
        private readonly IMapper _mapper;

        public UsersController(BookStoreContext dbContext, IUserRepository userRepository, IMapper mapper)
        {
            _dbContext = dbContext;
            _userRepository = userRepository;
            dbContext.ChangeTracker.QueryTrackingBehavior = Microsoft.EntityFrameworkCore.QueryTrackingBehavior.NoTracking;
            _mapper = mapper;
        }

        [HttpPut("{key}")]
        [EnableQuery]
        [Authorize]
        public IActionResult Put([FromODataUri] int key, [FromBody] InfoDto InfoDto)
        {
            var existedInfo = _userRepository.FindUserById(key);
            if (existedInfo == null)
            {
                return NotFound();
            }
            var user = _mapper.Map<User>(InfoDto);
            user.Password = existedInfo.Result.Password;
            _userRepository.UpdateUser(user);
            return Ok();
        }
    }
}
