﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Routing.Controllers;
using BusinessObjects.Models;
using BusinessObjects.Dtos;
using DataAccess.IRepository;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Formatter;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace eBookStoreWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ODataController
    {
        private readonly BookStoreContext _dbContext;
        private readonly IBookRepository _bookRepository;
        private readonly IMapper _mapper;


        public BooksController(BookStoreContext dbContext, IBookRepository bookRepository, IMapper mapper)
        {
            _dbContext = dbContext;
            _bookRepository = bookRepository;
            dbContext.ChangeTracker.QueryTrackingBehavior = Microsoft.EntityFrameworkCore.QueryTrackingBehavior.NoTracking;
            _mapper = mapper;
        }

        [HttpGet]
        [EnableQuery(PageSize = 10)]
        public IActionResult GetBooks()
        {
            var books = _bookRepository.GetBooks();
            return Ok(books);
        }

        [HttpGet("{key}")]
        [EnableQuery]
        public IActionResult GetBookById([FromODataUri] int key)
        {
            return Ok(_bookRepository.FindBookById(key));
        }

        [HttpPost]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Post([FromBody] BookDto bookDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }
            var book = _mapper.Map<Book>(bookDto);
            _bookRepository.SaveBook(book);
            return Created(book);
        }
        [HttpPut("{key}")]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Put([FromODataUri] int key, [FromBody] BookDto bookDto)
        {
            var existedBook = _bookRepository.FindBookById(key);
            if (existedBook == null)
            {
                return NotFound();
            }
            var book = _mapper.Map<Book>(bookDto);
            book.BookId = existedBook.BookId;
            _bookRepository.UpdateBook(book);
            return Ok();
        }

        [HttpDelete("{key}")]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Delete([FromODataUri] int key)
        {
            var book = _bookRepository.FindBookById(key);
            if (book == null)
            {
                return NotFound();
            }
            _bookRepository.DeleteBook(book);
            return Ok();
        }
    }
}
