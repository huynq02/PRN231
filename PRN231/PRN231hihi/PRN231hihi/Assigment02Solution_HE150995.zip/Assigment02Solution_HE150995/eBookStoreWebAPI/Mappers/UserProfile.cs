﻿using AutoMapper;
using BusinessObjects.Dtos;

namespace eBookStoreWebAPI.Mappers
{
    public class UserProfile : Profile
    {
        public UserProfile() {
            CreateMap<BusinessObjects.Models.User, InfoDto>();

            CreateMap<BusinessObjects.Models.User, LoginResponseDto>()
                .ForMember(des => des.Role, opt => opt.Ignore())
                .ForMember(des => des.Token, opt => opt.Ignore());

            CreateMap<InfoDto, BusinessObjects.Models.User>();
        }
    }
}
