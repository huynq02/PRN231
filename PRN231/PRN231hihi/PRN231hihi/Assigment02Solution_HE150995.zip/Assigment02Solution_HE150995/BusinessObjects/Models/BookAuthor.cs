﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessObjects.Models
{
    public class BookAuthor
    {
        [Required]
        public int AuthorId { get; set; }
        [Required]
        public int BookId { get; set; }
        [Range(0, 1000)]
        public int AuthorOrder { get; set; }
        [DefaultValue(0)]
        public float RoyalityPercentage { get; set; } = 0;

        [ForeignKey("AuthorId")]
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Author Author { get; set; }
        [ForeignKey("BookId")]
        [System.Text.Json.Serialization.JsonIgnore]
        public virtual Book Book { get; set; }
    }
}
