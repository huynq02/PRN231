﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Dtos
{
    public class AuthorDto
    {
        private const string PhoneNumberRegex = @"^\d{9,10}$";
        [Key]
        public int AuthorId { get; set; }
        [MaxLength(50)]
        [Required]
        public string LastName { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }
        [Required]
        [RegularExpression(PhoneNumberRegex, ErrorMessage = "The Phone field must be a number with 9 or 10 digits.")]
        public string Phone { get; set; }
        [MaxLength(200)]
        public string Address { get; set; }
        [MaxLength(100)]
        public string City { get; set; }
        [MaxLength(100)]
        public string State { get; set; }
        [Required]
        [Range(0, 100000)]
        public int Zip { get; set; }
        [Required]
        [MaxLength(320)]
        [DataType(DataType.EmailAddress)]
        public string EmailAddress { get; set; }
    }
}
