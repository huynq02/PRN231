﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Dtos
{
    public class LoginResponseDto
    {
        public int Id { get; set; }

        public string EmailAddress { get; set; } = null!;

        public string Source { get; set; } = null!;

        public string FirstName { get; set; } = null!;

        public string MiddleName { get; set; } = null!;

        public string LastName { get; set; } = null!;

        public int RoleId { get; set; }

        public int PublisherId { get; set; }

        public DateTime HireDate { get; set; }

        public string Role { get; set; } = null!;

        public string Token { get; set; } = null!;
    }
}
