﻿using BusinessObjects.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessObjects.Dtos
{
    public class InfoDto
    {
        public int UserId { get; set; }

        public string EmailAddress { get; set; } = null!;

        public string Source { get; set; } = null!;

        public string FirstName { get; set; } = null!;

        public string MiddleName { get; set; } = null!;

        public string LastName { get; set; } = null!;

        public int RoleId { get; set; }

        public int PubId { get; set; }

        public DateTime HireDate { get; set; }

        //public Publisher Publisher { get; set; } = null!;

        //public Role Role { get; set; } = null!;
    }
}
