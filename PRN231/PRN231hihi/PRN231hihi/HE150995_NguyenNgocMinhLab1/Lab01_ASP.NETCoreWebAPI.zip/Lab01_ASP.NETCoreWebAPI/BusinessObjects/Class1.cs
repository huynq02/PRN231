﻿namespace BusinessObjects
{
    public class Class1
    {

    }
}