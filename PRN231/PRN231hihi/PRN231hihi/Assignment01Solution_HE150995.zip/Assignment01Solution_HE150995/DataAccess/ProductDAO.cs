﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class ProductDAO
    {
        public static List<Product> GetProducts()
        {
            var listProducts = new List<Product>();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    listProducts = context.Products.ToList();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return listProducts;
        }

        public static void SaveProduct(Product p)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Products.Add(p);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteProduct(Product product)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    var p = context.Products.SingleOrDefault(p => p.ProductId == product.ProductId);
                    if (p != null)
                    {
                        context.Products.Remove(p);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public static Product FindProductById(int id)
        {
            Product product = new Product();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    product = context.Products.SingleOrDefault(p => p.ProductId.Equals(id));
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return product;
        }

        public static void UpdateProduct(Product product)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Entry<Product>(product).State = EntityState.Modified;
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
