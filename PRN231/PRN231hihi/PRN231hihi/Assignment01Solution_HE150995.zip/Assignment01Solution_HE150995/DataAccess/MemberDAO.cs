﻿using BusinessObject.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class MemberDAO
    {
        public static List<Member> GetMembers()
        {
            var listMembers = new List<Member>();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    listMembers = context.Members.ToList();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return listMembers;
        }

        public static void SaveMember(Member p)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Members.Add(p);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteMember(Member Member)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    var p = context.Members.SingleOrDefault(p => p.MemberId == Member.MemberId);
                    if (p != null)
                    {
                        context.Members.Remove(p);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public static Member FindMemberById(int id)
        {
            Member Member = new Member();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    Member = context.Members.SingleOrDefault(p => p.MemberId.Equals(id));
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return Member;
        }

        public static void UpdateMember(Member Member)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Entry<Member>(Member).State = EntityState.Modified;
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
