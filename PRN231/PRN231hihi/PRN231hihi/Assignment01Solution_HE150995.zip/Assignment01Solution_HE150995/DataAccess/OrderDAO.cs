﻿using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class OrderDAO
    {
        public static List<Order> GetOrders()
        {
            var listOrders = new List<Order>();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    listOrders = context.Orders.ToList();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return listOrders;
        }
        public static void SaveOrder(Order p)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Orders.Add(p);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteOrder(Order Order)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    var p = context.Orders.SingleOrDefault(p => p.OrderId == Order.OrderId);
                    if (p != null)
                    {
                        context.Orders.Remove(p);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public static Order FindOrderById(int id)
        {
            Order Order = new Order();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    Order = context.Orders.SingleOrDefault(p => p.OrderId.Equals(id));
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return Order;
        }

        public static void UpdateOrder(Order Order)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Entry<Order>(Order).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
