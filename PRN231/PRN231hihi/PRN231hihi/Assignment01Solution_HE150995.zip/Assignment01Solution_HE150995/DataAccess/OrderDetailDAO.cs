﻿
using BusinessObject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess
{
    public class OrderDetailDAO
    {
        public static List<OrderDetail> GetOrderDetails()
        {
            var listOrderDetails = new List<OrderDetail>();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    listOrderDetails = context.OrderDetails.ToList();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return listOrderDetails;
        }
        public static void SaveOrderDetail(OrderDetail p)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.OrderDetails.Add(p);
                    context.SaveChanges();
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteOrderDetail(OrderDetail OrderDetail)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    var p = context.OrderDetails.SingleOrDefault(p => p.OrderId == OrderDetail.OrderId && p.ProductId == OrderDetail.ProductId);
                    if (p != null)
                    {
                        context.OrderDetails.Remove(p);
                        context.SaveChanges();
                    }
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        public static OrderDetail FindOrderDetailById(int orderId, int productId)
        {
            OrderDetail OrderDetail = new OrderDetail();

            try
            {
                using (var context = new Prn231As1Context())
                {
                    OrderDetail = context.OrderDetails.SingleOrDefault(p => p.OrderId == orderId && p.ProductId == productId);
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
            return OrderDetail;
        }

        public static void UpdateOrderDetail(OrderDetail OrderDetail)
        {
            try
            {
                using (var context = new Prn231As1Context())
                {
                    context.Entry<OrderDetail>(OrderDetail).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                    context.SaveChanges();
                }
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
    }
}
