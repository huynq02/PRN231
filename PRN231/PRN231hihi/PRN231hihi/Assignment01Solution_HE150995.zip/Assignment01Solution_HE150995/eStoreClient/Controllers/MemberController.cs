﻿using BusinessObject.Dtos;
using BusinessObject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Text.Json;

namespace eStoreClient.Controllers
{
    public class MemberController : Controller
    {
        private readonly HttpClient _httpClient;

        private string MemberApiUrl;
        public MemberController()
        {
            _httpClient = new HttpClient();
            var contentType = new MediaTypeWithQualityHeaderValue("application/json");
            _httpClient.DefaultRequestHeaders.Accept.Add(contentType);
            MemberApiUrl = "http://localhost:5045/api/Member";
            
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            List<MemberDto> memberDtos = await GetMembers();
            return View(memberDtos);
        }

        private async Task<List<MemberDto>> GetMembers()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(MemberApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<MemberDto>>(strData, options);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            List<MemberDto> memberDtos = await GetMembers();
            MemberDto memberDto = memberDtos.FirstOrDefault(p => p.MemberId == id);
            if (memberDto == null)
            {
                return NotFound();
            }

            return View(memberDto);

        }
        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            List<MemberDto> memberDtos = await GetMembers();
            MemberDto memberDto = memberDtos.FirstOrDefault(p => p.MemberId == id);
            if (memberDto == null)
            {
                return NotFound();
            }
            return View(memberDto);

        }

        public async Task<IActionResult> EditMember([FromForm] MemberDto MemberDto)
        {
            using (var respone = await _httpClient.PutAsJsonAsync(MemberApiUrl + "/id?id=" + MemberDto.MemberId, MemberDto))
            {
                string apiResponse = await respone.Content.ReadAsStringAsync();
            }
            return Redirect("/Member/Index");
        }

        public async Task<IActionResult> Delete(int id)
        {
            List<MemberDto> MemberDtos = await GetMembers();
            MemberDto MemberDto = MemberDtos.FirstOrDefault(p => p.MemberId == id);
            if (MemberDto == null)
            {
                return NotFound();
            }

            String url = MemberApiUrl + "/id?id=" + id;
            await _httpClient.DeleteAsync(url);

            return Redirect("/Member/Index");
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddMember([FromForm] MemberDto MemberDto)
        {
            using (var respone = await _httpClient.PostAsJsonAsync(MemberApiUrl, MemberDto))
            {
                string apiResponse = await respone.Content.ReadAsStringAsync();
            }
            return Redirect("/Member/Index");
        }
    }
}
