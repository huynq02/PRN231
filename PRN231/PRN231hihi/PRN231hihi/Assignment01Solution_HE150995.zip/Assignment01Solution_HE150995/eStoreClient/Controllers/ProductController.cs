﻿using BusinessObject.Models;
using BusinessObject.Dtos;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Text.Json;
using DataAccess;

namespace eStoreClient.Controllers
{
    public class ProductController : Controller
    {
        private readonly HttpClient _httpClient;

        private string ProductApiUrl;

        private string CategoryApiUrl;

        private string OrderDetailUrl;

        public ProductController()
        {
            _httpClient = new HttpClient();
            var contentType = new MediaTypeWithQualityHeaderValue("application/json");
            _httpClient.DefaultRequestHeaders.Accept.Add(contentType);
            ProductApiUrl = "http://localhost:5045/api/Product";
            CategoryApiUrl = "http://localhost:5045/api/Category";
            OrderDetailUrl = "http://localhost:5045/api/OrderDetail";
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            List<ProductDto> products = await GetProducts();
            return View(products);
        }

        private async Task<List<ProductDto>> GetProducts()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(ProductApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<ProductDto>>(strData, options);
        }

        private async Task<List<Category>> GetCategories()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(CategoryApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<Category>>(strData, options);
        }

        private async Task<List<OrderDetailDto>> GetOrderDetails()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(OrderDetailUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<OrderDetailDto>>(strData, options);
        }

        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            List<Category> categories = await GetCategories();
            List<ProductDto> productDtos = await GetProducts();
            ProductDto productDto = productDtos.FirstOrDefault(p => p.ProductId == id);
            var category = categories.FirstOrDefault(c => c.CategoryId == productDto.CategoryId);
            ViewData["CategoryName"] = category.CategoryName;
            if (productDto == null)
            {
                return NotFound();
            }

            return View(productDto);

        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {

            ViewData["Category"] = await GetCategories();
            List<ProductDto> productDtos = await GetProducts();
            ProductDto productDto = productDtos.FirstOrDefault(p => p.ProductId == id);
            if (productDto == null)
            {
                return NotFound();
            }
            return View(productDto);
        }

        public async Task<IActionResult> EditProduct([FromForm] ProductDto productDto)
        {
            using (var respone = await _httpClient.PutAsJsonAsync(ProductApiUrl + "/id?id=" + productDto.ProductId, productDto))
            {
                string apiResponse = await respone.Content.ReadAsStringAsync();
            }
            return Redirect("/Product/Index");
        }

        public async Task<IActionResult> Delete(int id)
        {
            List<ProductDto> productDtos = await GetProducts();
            ProductDto productDto = productDtos.FirstOrDefault(p => p.ProductId == id);
            if (productDto == null)
            {
                return NotFound();
            }
            if (checkProductExistOrderDetail(productDto).Result)
            {
                //Xu ly notification

                return Redirect("/Product/Index");

            }

            String url = ProductApiUrl + "/id?id=" + id;
            await _httpClient.DeleteAsync(url);
            
            return Redirect("/Product/Index");
        }

        public async Task<bool> checkProductExistOrderDetail(ProductDto productDto)
        {
            List<OrderDetailDto> orderDetailDtos = await GetOrderDetails();
            var orderDetail = orderDetailDtos.FirstOrDefault(o => o.ProductId == productDto.ProductId);
            if(orderDetail== null)
            {
                return false;
            }
            return true;

        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            ViewData["Category"] = await GetCategories();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct([FromForm] ProductDto product)
        {
            using (var respone = await _httpClient.PostAsJsonAsync(ProductApiUrl, product))
            {
                string apiResponse = await respone.Content.ReadAsStringAsync();
            }
            return Redirect("/Product/Index");
        }
    }
}
