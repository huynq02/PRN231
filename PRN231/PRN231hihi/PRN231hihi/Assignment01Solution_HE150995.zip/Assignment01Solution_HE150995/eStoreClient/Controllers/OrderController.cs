﻿using BusinessObject.Dtos;
using BusinessObject.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text.Json;

namespace eStoreClient.Controllers
{
    public class OrderController : Controller
    {
        private readonly HttpClient _httpClient;

        private string OrderApiUrl;
        private string MemberApiUrl;
        private string OrderDetailApiUrl;
        private string ProductApiUrl;

        public OrderController()
        {
            _httpClient = new HttpClient();
            var contentType = new MediaTypeWithQualityHeaderValue("application/json");
            _httpClient.DefaultRequestHeaders.Accept.Add(contentType);
            OrderApiUrl = "http://localhost:5045/api/Order";
            MemberApiUrl = "http://localhost:5045/api/Member";
            OrderDetailApiUrl = "http://localhost:5045/api/OrderDetail";
            ProductApiUrl = "http://localhost:5045/api/Product";

        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            List<OrderDto> orderDtos = await GetOrders();
            List<MemberDto> memberDtos = await GetMembers();
            ViewData["Member"] = memberDtos;

            return View(orderDtos);
        }

        private async Task<List<OrderDto>> GetOrders()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(OrderApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<OrderDto>>(strData, options);
        }

        private async Task<List<MemberDto>> GetMembers()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(MemberApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<MemberDto>>(strData, options);
        }

        public async Task<IActionResult> Details(int? id)
        {
            List<OrderDetailDto> orderDetailDtos = await GetOrderDetailsByOrderId(id);
            ViewData["ProductDtos"] = await GetProducts();
            ViewData["OrderDetailDtos"] = orderDetailDtos;

            List<OrderDto> orderDtos = await GetOrders();
            OrderDto orderDto = orderDtos.FirstOrDefault(p => p.OrderId == id);

            List<MemberDto> memberDtos = await GetMembers();
            MemberDto memberDto = memberDtos.FirstOrDefault(m => m.MemberId == orderDto.MemberId);
            ViewData["CompanyName"] = memberDto.CompanyName;

            if (orderDto == null)
            {
                return NotFound();
            }

            return View(orderDto);

        }

        public async Task<List<OrderDetailDto>> GetOrderDetailsByOrderId(int? orderId)
        {
            HttpResponseMessage response = await _httpClient.GetAsync(OrderDetailApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            List<OrderDetailDto> orderDetailDtos =  JsonSerializer.Deserialize<List<OrderDetailDto>>(strData, options);
            return orderDetailDtos.FindAll(x => x.OrderId == orderId);
        }

        private async Task<List<ProductDto>> GetProducts()
        {
            HttpResponseMessage response = await _httpClient.GetAsync(ProductApiUrl);
            string strData = await response.Content.ReadAsStringAsync();
            var options = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
            return JsonSerializer.Deserialize<List<ProductDto>>(strData, options);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(int? id)
        {
            ViewData["MemberDtos"] = await GetMembers();
            List<OrderDto> orderDtos = await GetOrders();
            OrderDto orderDto = orderDtos.FirstOrDefault(p => p.OrderId == id);
            if (orderDto == null)
            {
                return NotFound();
            }
            return View(orderDto);
        }

        public async Task<IActionResult> EditOrder([FromForm] OrderDto OrderDto)
        {
            using (var respone = await _httpClient.PutAsJsonAsync(OrderApiUrl + "/id?id=" + OrderDto.OrderId, OrderDto))
            {
                string apiResponse = await respone.Content.ReadAsStringAsync();
            }
            return Redirect("/Order/Index");
        }
    }
}
