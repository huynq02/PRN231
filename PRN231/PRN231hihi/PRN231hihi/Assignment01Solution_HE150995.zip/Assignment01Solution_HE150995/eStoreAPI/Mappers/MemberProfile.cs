﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;

namespace eStoreAPI.Mappers
{
    public class MemberProfile : Profile
    {
        public MemberProfile()
        {
            CreateMap<Member, MemberDto>()
                .ForMember(dest => dest.MemberId, otp => otp.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.Email, otp => otp.MapFrom(src => src.Email))
                .ForMember(dest => dest.CompanyName, otp => otp.MapFrom(src => src.CompanyName))
                .ForMember(dest => dest.City, otp => otp.MapFrom(src => src.City))
                .ForMember(dest => dest.Country, otp => otp.MapFrom(src => src.Country))
                .ForMember(dest => dest.Password, otp => otp.MapFrom(src => src.Password));
            
            CreateMap<MemberDto, Member>()
                .ForMember(dest => dest.MemberId, otp => otp.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.Email, otp => otp.MapFrom(src => src.Email))
                .ForMember(dest => dest.CompanyName, otp => otp.MapFrom(src => src.CompanyName))
                .ForMember(dest => dest.City, otp => otp.MapFrom(src => src.City))
                .ForMember(dest => dest.Country, otp => otp.MapFrom(src => src.Country))
                .ForMember(dest => dest.Password, otp => otp.MapFrom(src => src.Password));

        }
    }
}
