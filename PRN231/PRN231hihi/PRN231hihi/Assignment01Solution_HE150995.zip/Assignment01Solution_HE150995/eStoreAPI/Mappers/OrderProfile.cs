﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;

namespace eStoreAPI.Mappers
{
    public class OrderProfile : Profile
    {
        public OrderProfile()
        {
            CreateMap<Order, OrderDto>()
                .ForMember(dest => dest.OrderId, otp => otp.MapFrom(src => src.OrderId))
                .ForMember(dest => dest.MemberId, otp => otp.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.OrderDate, otp => otp.MapFrom(src => src.OrderDate))
                .ForMember(dest => dest.RequireDate, otp => otp.MapFrom(src => src.RequireDate))
                .ForMember(dest => dest.ShippedDate, otp => otp.MapFrom(src => src.ShippedDate))
                .ForMember(dest => dest.Freight, otp => otp.MapFrom(src => src.Freight));
            //.ForMember(dest => dest.OrderDetails, otp => otp.MapFrom(src => src.OrderDetails))

            CreateMap<OrderDto, Order>()
                .ForMember(dest => dest.OrderId, otp => otp.MapFrom(src => src.OrderId))
                .ForMember(dest => dest.MemberId, otp => otp.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.OrderDate, otp => otp.MapFrom(src => src.OrderDate))
                .ForMember(dest => dest.RequireDate, otp => otp.MapFrom(src => src.RequireDate))
                .ForMember(dest => dest.ShippedDate, otp => otp.MapFrom(src => src.ShippedDate))
                .ForMember(dest => dest.Freight, otp => otp.MapFrom(src => src.Freight));
            //.ForMember(dest => dest.OrderDetails, otp => otp.MapFrom(src => src.OrderDetails))
        }

    }
}
