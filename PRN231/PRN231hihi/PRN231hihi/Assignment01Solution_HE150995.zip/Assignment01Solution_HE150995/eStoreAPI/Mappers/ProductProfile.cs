﻿using AutoMapper;
using BusinessObject.Models;
using BusinessObject.Dtos;
using DataAccess;

namespace eStoreAPI.Mappers
{
    public class ProductProfile : Profile
    {
        public ProductProfile()
        {
            CreateMap<Product, ProductDto>()
            .ForMember(dest => dest.ProductId, otp => otp.MapFrom(src => src.ProductId))
            .ForMember(dest => dest.CategoryId, otp => otp.MapFrom(src => src.CategoryId))
            .ForMember(dest => dest.ProductName, otp => otp.MapFrom(src => src.ProductName))
            .ForMember(dest => dest.Weight, otp => otp.MapFrom(src => src.Weight))
            .ForMember(dest => dest.UnitPrice, otp => otp.MapFrom(src => src.UnitPrice))
            .ForMember(dest => dest.UnitsInStock, otp => otp.MapFrom(src => src.UnitsInStock));

            CreateMap<ProductDto, Product>()
           .ForMember(dest => dest.ProductId, otp => otp.MapFrom(src => src.ProductId))
           .ForMember(dest => dest.CategoryId, otp => otp.MapFrom(src => src.CategoryId))
           .ForMember(dest => dest.ProductName, otp => otp.MapFrom(src => src.ProductName))
           .ForMember(dest => dest.Weight, otp => otp.MapFrom(src => src.Weight))
           .ForMember(dest => dest.UnitPrice, otp => otp.MapFrom(src => src.UnitPrice))
           .ForMember(dest => dest.UnitsInStock, otp => otp.MapFrom(src => src.UnitsInStock));
        }

    }
}
