﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;

namespace eStoreAPI.Mappers
{
    public class OrderDetailProfile : Profile
    {
        public OrderDetailProfile()
        {
            CreateMap<OrderDetail, OrderDetailDto>()
                .ForMember(dest => dest.OrderId, otp => otp.MapFrom(src => src.OrderId))
                .ForMember(dest => dest.ProductId, otp => otp.MapFrom(src => src.ProductId))
                .ForMember(dest => dest.UnitPrice, otp => otp.MapFrom(src => src.UnitPrice))
                .ForMember(dest => dest.Quantity, otp => otp.MapFrom(src => src.Quantity))
                .ForMember(dest => dest.Discount, otp => otp.MapFrom(src => src.Discount));

            CreateMap<OrderDetailDto, OrderDetail>()
                .ForMember(dest => dest.OrderId, otp => otp.MapFrom(src => src.OrderId))
                .ForMember(dest => dest.ProductId, otp => otp.MapFrom(src => src.ProductId))
                .ForMember(dest => dest.UnitPrice, otp => otp.MapFrom(src => src.UnitPrice))
                .ForMember(dest => dest.Quantity, otp => otp.MapFrom(src => src.Quantity))
                .ForMember(dest => dest.Discount, otp => otp.MapFrom(src => src.Discount));
        }
    }
}
