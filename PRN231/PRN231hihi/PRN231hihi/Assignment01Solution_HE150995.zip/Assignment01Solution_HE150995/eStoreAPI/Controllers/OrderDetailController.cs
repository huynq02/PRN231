﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace eStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderDetailController : ControllerBase
    {
        private IOrderDetailRepository repository = new OrderDetailRepository();
        private readonly IMapper _mapper;
        public OrderDetailController(IMapper mapper)
        {
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<OrderDetailDto>> GetOrderDetails() => _mapper.Map<List<OrderDetailDto>>(repository.GetOrderDetails());

        [HttpPost]
        public IActionResult PostOrderDetail([FromBody] OrderDetailDto OrderDetailDto)
        {
            OrderDetail p = _mapper.Map<OrderDetail>(OrderDetailDto);
            repository.SaveOrderDetail(p);
            return NoContent();
        }

        [HttpDelete("id")]
        public IActionResult DeleteOrderDetail(int orderId, int productId)
        {
            var OrderDetail = repository.GetOrderDetailById(orderId, productId);
            if (OrderDetail == null)
            {
                return NotFound();
            }
            repository.DeleteOrderDetail(OrderDetail);
            return NoContent();
        }

        [HttpPut("id")]
        public IActionResult UpdateOrder(int orderId, int productId, [FromBody] OrderDetailDto OrderDetailDto)
        {
            var p = repository.GetOrderDetailById(orderId, productId);
            if (p == null)
            {
                return NotFound();
            }
            p = _mapper.Map<OrderDetail>(OrderDetailDto);
            p.OrderId = orderId;
            p.ProductId = productId;
            repository.UpdateOrderDetail(p);
            return NoContent();
        }
    }
}
