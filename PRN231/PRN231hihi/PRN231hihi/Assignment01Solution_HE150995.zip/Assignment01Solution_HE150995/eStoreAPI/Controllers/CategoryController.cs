﻿using BusinessObject.Models;
using Microsoft.AspNetCore.Mvc;
using Repositories;


namespace eStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private ICategoryRepository categoryRepository = new CategoryRepository();

        [HttpGet]
        public List<Category> GetCategories() => categoryRepository.GetCategories();
    }
}
