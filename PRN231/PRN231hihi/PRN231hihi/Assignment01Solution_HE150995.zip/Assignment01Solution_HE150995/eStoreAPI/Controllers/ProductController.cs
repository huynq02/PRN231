﻿using BusinessObject.Models;
using BusinessObject.Dtos;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repositories;
using AutoMapper;
using DataAccess;

namespace eStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProductRepository repository = new ProductRepository();
        private readonly IMapper _mapper;
        public ProductController(IMapper mapper)
        {
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<ProductDto>> GetProducts() => _mapper.Map<List<ProductDto>>(repository.GetProducts());

        [HttpPost]
        public IActionResult PostProduct([FromBody] ProductDto productDto)
        {
            Product p = _mapper.Map<Product>(productDto);
            repository.SaveProduct(p);
            return NoContent();
        }

        //Get: ProductsController/Delete/5
        [HttpDelete("id")]
        public IActionResult DeleteProduct(int id)
        {
            var product = repository.GetProductById(id);
            if (product == null)
            {
                return NotFound();
            }
            repository.DeleteProduct(product);
            return NoContent();
        }

        [HttpPut("id")]
        public IActionResult UpdateProduct(int id, [FromBody] ProductDto productDto)
        {
            var p = repository.GetProductById(id);
            if (p == null)
            {
                return NotFound();
            }
            p = _mapper.Map<Product>(productDto);
            repository.UpdateProduct(p);
            return NoContent();
        }
    }
}
