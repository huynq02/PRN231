﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace eStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private IOrderRepository repository = new OrderRepository();
        private readonly IMapper _mapper;
        public OrderController(IMapper mapper)
        {
            _mapper = mapper;
        }

        [HttpGet]
        public ActionResult<IEnumerable<OrderDto>> GetOrders() => _mapper.Map<List<OrderDto>>(repository.GetOrders());

        [HttpPost]
        public IActionResult PostOrder([FromBody] OrderDto OrderDto)
        {
            Order p = _mapper.Map<Order>(OrderDto);
            repository.SaveOrder(p);
            return NoContent();
        }
        //Get: ProductsController/Delete/5
        [HttpDelete("id")]
        public IActionResult DeleteOrder(int id)
        {   
            var Order = repository.GetOrderById(id);
            if (Order == null)
            {
                return NotFound();
            }
            repository.DeleteOrder(Order);
            return NoContent();
        }

        [HttpPut("id")]
        public IActionResult UpdateOrder(int id, [FromBody] OrderDto Order)
        {
            var p = repository.GetOrderById(id);
            if (p == null)
            {
                return NotFound();
            }
            p = _mapper.Map<Order>(Order);
            p.OrderId = id;
            repository.UpdateOrder(p);
            return NoContent();
        }
    }
}

