﻿using AutoMapper;
using BusinessObject.Dtos;
using BusinessObject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Repositories;

namespace eStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberController : ControllerBase
    {
        private IMemberRepository repository = new MemberRepository();
        private readonly IMapper _mapper;
        public MemberController(IMapper mapper)
        {
            _mapper = mapper;
        }
        [HttpGet]
        public ActionResult<IEnumerable<MemberDto>> GetMembers() => _mapper.Map<List<MemberDto>>(repository.GetMembers());

        [HttpPost]
        public IActionResult PostMember([FromBody] MemberDto MemberDto)
        {
            Member p = _mapper.Map<Member>(MemberDto);
            repository.SaveMember(p);
            return NoContent();
        }

        //Get: MembersController/Delete/5
        [HttpDelete("id")]
        public IActionResult DeleteMember(int id)
        {
            var Member = repository.GetMemberById(id);
            if (Member == null)
            {
                return NotFound();
            }
            repository.DeleteMember(Member);
            return NoContent();
        }

        //Get: MembersController/Delete/5
        [HttpPut("id")]
        public IActionResult UpdateMember(int id, [FromBody] MemberDto Member)
        {
            var p = repository.GetMemberById(id);
            if (p == null)
            {
                return NotFound();
            }
            p = _mapper.Map<Member>(Member);
            p.MemberId = id;
            repository.UpdateMember(p);
            return NoContent();
        }
    }
}
