using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Publisher
{
    [Authorize(Roles = "admin")]
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public BusinessObjects.Dtos.PublisherDto PublisherModel { get; set; }
        public async Task<IActionResult> OnGet(int PubId)
        {
            var client = new Services(HttpContext);
            var Publisher = await client.Get<OdataList<BusinessObjects.Dtos.PublisherDto>>($"/odata/Publishers?filter=PubId eq {PubId}");
            if (Publisher == null) return NotFound();

            PublisherModel = Publisher.Value.FirstOrDefault();
            return Page();
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Put($"/odata/Publishers/{PublisherModel.PubId}", PublisherModel);
            if (result == null) return NotFound();

            return RedirectToPage("/Publisher/Details", new { PublisherModel.PubId });
        }
    }
}
