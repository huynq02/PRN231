using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Publisher
{
    [Authorize(Roles = "admin")]
    public class AddModel : PageModel
    {
        [BindProperty]
        public BusinessObjects.Dtos.PublisherDto PublisherModel { get; set; }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Post($"/odata/Publishers", PublisherModel);
            if (result == null) return NotFound();

            return RedirectToPage("/Publisher/Index"); ;
        }
    }
}
