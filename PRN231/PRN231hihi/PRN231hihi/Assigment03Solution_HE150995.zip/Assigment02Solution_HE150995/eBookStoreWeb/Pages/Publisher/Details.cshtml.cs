using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Publisher
{
    [Authorize]
    public class DetailsModel : PageModel
    {
        public BusinessObjects.Models.Publisher PublisherModel { get; set; }

        public async Task<IActionResult> OnGet(int pubId)
        {
            var client = new Services(HttpContext);
            var publisher = await client.Get<OdataList<BusinessObjects.Models.Publisher>>($"/odata/publishers?filter=pubId eq {pubId}");
            if (publisher == null) return NotFound();

            PublisherModel = publisher.Value.FirstOrDefault();
            return Page();
        }
    }
}
