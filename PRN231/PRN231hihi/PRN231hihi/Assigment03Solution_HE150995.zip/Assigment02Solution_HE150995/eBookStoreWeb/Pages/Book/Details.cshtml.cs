using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Book
{
    public class DetailsModel : PageModel
    {
        public BusinessObjects.Models.Book BookModel { get; set; }

        public async Task<IActionResult> OnGet(int BookId)
        {
            var client = new Services(HttpContext);
            var Book = await client.Get<OdataList<BusinessObjects.Models.Book>>($"/odata/Books?filter=BookId eq {BookId}");
            if (Book == null) return NotFound();

            BookModel = Book.Value.FirstOrDefault();
            ViewData["PublisherName"] = await GetPublisherName(BookModel.PubId);
            return Page();
        }

        public async Task<string> GetPublisherName(int PubId)
        {
            var client = new Services(HttpContext);
            var result = await client.Get<OdataList<BusinessObjects.Models.Publisher>>($"/odata/Publishers?filter=PubId eq {PubId}");
            if (result != null)
            {
                return result.Value.FirstOrDefault().PublisherName;
            }
            return string.Empty;
        }
    }
}
