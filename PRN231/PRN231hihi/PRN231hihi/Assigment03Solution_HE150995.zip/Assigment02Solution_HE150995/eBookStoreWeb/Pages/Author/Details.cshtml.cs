using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Author
{
    [Authorize]
    public class DetailsModel : PageModel
    {
        public BusinessObjects.Models.Author AuthorModel { get; set; } 

        public async Task<IActionResult> OnGet(int authorId)
        {
            var client = new Services(HttpContext);
            var author = await client.Get<OdataList<BusinessObjects.Models.Author>>($"/odata/authors?filter=authorId eq {authorId}");
            if (author == null) return NotFound();

            AuthorModel = author.Value.FirstOrDefault();
            return Page();
        }
    }
}
