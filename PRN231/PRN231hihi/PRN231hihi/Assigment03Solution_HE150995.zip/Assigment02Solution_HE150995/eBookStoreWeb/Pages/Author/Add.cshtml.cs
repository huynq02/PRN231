using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.Author
{
    [Authorize(Roles = "admin")]
    public class AddModel : PageModel
    {
        [BindProperty]
        public BusinessObjects.Dtos.AuthorDto AuthorModel { get; set; }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Post($"/odata/authors", AuthorModel);
            if (result == null) return NotFound();

            return RedirectToPage("/Author/Index"); ;
        }
    }
}
