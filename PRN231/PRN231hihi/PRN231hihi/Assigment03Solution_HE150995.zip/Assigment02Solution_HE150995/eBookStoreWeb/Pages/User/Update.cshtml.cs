using BusinessObjects.Dtos;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.User
{
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public InfoDto InfoModel { get; set; } = null!;

        public async Task<IActionResult> OnGet()
        {
            var client = new Services(HttpContext);
            var res = await client.Get<InfoDto>("/api/auth/user");
            if (res == null) return NotFound();
            InfoModel = res;
            ViewData["ListPublisher"] = await GetPublishers();
            return Page();
        }

        public async Task<List<BusinessObjects.Models.Publisher>> GetPublishers()
        {
            var _service = new Services(HttpContext);
            var result = await _service.Get<OdataList<BusinessObjects.Models.Publisher>>("/odata/Publishers");
            List<BusinessObjects.Models.Publisher> publishers = new List<BusinessObjects.Models.Publisher>();
            if (result != null)
            {
                publishers = result.Value.ToList();
            }
            return publishers;
        }

        public async Task<IActionResult> OnPost()
        {
            if (!ModelState.IsValid)
            {
                ViewData["ListPublisher"] = await GetPublishers();
                return Page();
            }
            var client = new Services(HttpContext);
            var result = await client.Put($"/odata/Users/{InfoModel.UserId}", InfoModel);
            if (result == null) return NotFound();

            return RedirectToPage("/User/Index");
        }
    }
}
