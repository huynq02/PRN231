using BusinessObjects.Dtos;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace eBookStoreWeb.Pages.User
{
    [Authorize]
    public class IndexModel : PageModel
    {
        public InfoDto InfoModel { get; set; } = null!;

        public async Task<IActionResult> OnGet()
        {
            var client = new Services(HttpContext);
            var res = await client.Get<InfoDto>("/api/auth/user");
            if (res == null) return NotFound();

            InfoModel = res;
            ViewData["PublisherName"] = await GetPublisherName(InfoModel.PubId);
            return Page();
        }

        public async Task<string> GetPublisherName(int PubId)
        {
            var client = new Services(HttpContext);
            var result = await client.Get<OdataList<BusinessObjects.Models.Publisher>>($"/odata/Publishers?filter=PubId eq {PubId}");
            if (result != null)
            {
                return result.Value.FirstOrDefault().PublisherName;
            }
            return string.Empty;
        }
    }
}
