﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace BusinessObjects.Models
{
    public partial class BookStoreContext : DbContext
    {
        public BookStoreContext()
        {
        }

        public BookStoreContext(DbContextOptions<BookStoreContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Author> Authors { get; set; }
        public virtual DbSet<Book> Books { get; set; } 
        public virtual DbSet<BookAuthor> BookAuthors { get; set; } 
        public virtual DbSet<Publisher> Publishers { get; set; } 
        public virtual DbSet<Role> Roles { get; set; } 
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
				var builder = new ConfigurationBuilder()
							  .SetBasePath(Directory.GetCurrentDirectory())
							  .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
				IConfigurationRoot configuration = builder.Build();
				optionsBuilder.UseSqlServer(configuration.GetConnectionString("DefaultConnection"));
			}
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Publisher>(entity =>
            {
                entity.HasKey(e => e.PubId);
            });
            modelBuilder.Entity<Author>(entity =>
            {
                entity.HasKey(e => e.AuthorId);
            });
            modelBuilder.Entity<Book>(entity =>
            {

                entity.Property(t => t.BookId).ValueGeneratedOnAdd();
                entity.HasKey(e => e.BookId);
                entity.HasOne(d => d.Publisher)
                  .WithMany(p => p.Books)
                  .HasForeignKey(d => d.PubId);
            });
            modelBuilder.Entity<Publisher>(entity =>
            {
                entity.HasKey(e => e.PubId);
            });
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserId);
                entity.HasOne(d => d.Publisher)
                .WithMany(p => p.Users)
                .HasForeignKey(d => d.PubId);
                entity.HasOne(d => d.Role)
                 .WithMany(p => p.Users)
                 .HasForeignKey(d => d.RoleId);
            });
            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.RoleId);
            });
            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.RoleId);
            });
            modelBuilder.Entity<BookAuthor>(entity =>
            {
                entity.HasKey(e => new { e.AuthorId, e.BookId });
                entity.HasOne(d => d.Book)
                 .WithMany(p => p.BookAuthors)
                 .HasForeignKey(d => d.BookId);

                entity.HasOne(d => d.Author)
              .WithMany(p => p.BookAuthors)
              .HasForeignKey(d => d.AuthorId);

            });

        }


    }
}
