﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BusinessObjects.Models
{
    public class Author
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int AuthorId { get; set; }
        [MaxLength(50)]
        [Required]
        public string LastName { get; set; }
        [Required]
        [MaxLength(50)]
        public string FirstName { get; set; }

        [Required]
        public string Phone { get; set; }
        [MaxLength(200)]
        public string Address { get; set; }
        [MaxLength(100)]
        public string City { get; set; }
        [MaxLength(100)]
        public string State { get; set; }
        [Required]
        [Range(0, 100000)]
        public int Zip { get; set; }
        [Required]
        [MaxLength(320)]
        [DataType(DataType.EmailAddress)]
        public string EmailAddress { get; set; }

        [System.Text.Json.Serialization.JsonIgnore]
        public virtual ICollection<BookAuthor> BookAuthors { get; set; }
    }
}
