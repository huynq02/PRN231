﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class RoleRepository : IRoleRepository
    {
        public void DeleteRole(Role role) => RoleDAO.DeleteRole( role);

        public Role FindRoleById(int id) => RoleDAO.FindRoleById( id);

        public List<Role> GetRoles() => RoleDAO.GetRoles();

        public void SaveRole(Role role) => RoleDAO.SaveRole( role);

        public void UpdateRole(Role role) => RoleDAO.UpdateRole( role);
    }
}
