﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class PublisherRepository : IPublisherRepository
    {
        public void DeletePublisher(Publisher publisher) => PublisherDAO.DeletePublisher(publisher);

        public Publisher FindPublisherById(int id) => PublisherDAO.FindPublisherById(id);

        public List<Publisher> GetPublishers() => PublisherDAO.GetPublishers();

        public void SavePublisher(Publisher publisher) => PublisherDAO.SavePublisher(publisher);

        public void UpdatePublisher(Publisher publisher) => PublisherDAO.UpdatePublisher(publisher);
    }
}
