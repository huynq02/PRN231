﻿using BusinessObjects.Models;
using DataAccess.DAO;
using DataAccess.IRepository;
using System.Collections.Generic;

namespace DataAccess.Repositories
{
    public class UserRepository : IUserRepository
    {
        public void DeleteUser(User user) => UserDAO.DeleteUser(user);

        public async Task<User?> FindUserById(int id) => await UserDAO.FindUserById(id);

        public List<User> GetUsers() => UserDAO.GetUsers();

        public void SaveUser(User user) => UserDAO.SaveUser(user);

        public void UpdateUser(User user) => UserDAO.UpdateUser(user);
        public async Task<User?> Login(string emailAddress, string password) => await UserDAO.Login(emailAddress, password);
    }
}
