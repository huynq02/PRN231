﻿using BusinessObjects.Models;
using System.Collections.Generic;

namespace DataAccess.IRepository
{
    public interface IPublisherRepository
    {
        void DeletePublisher(  Publisher publisher);
        Publisher FindPublisherById(  int id);
        List<Publisher> GetPublishers();
        void SavePublisher(  Publisher publisher);
        void UpdatePublisher(  Publisher publisher);
    }
}
