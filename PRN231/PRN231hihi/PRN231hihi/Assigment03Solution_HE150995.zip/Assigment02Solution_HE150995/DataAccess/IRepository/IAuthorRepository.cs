﻿using BusinessObjects.Models;
using System.Collections.Generic;

namespace DataAccess.IRepository
{
    public interface IAuthorRepository
    {
        void DeleteAuthor( Author author);
        Author FindAuthorById(int id);
        List<Author> GetAuthors( );
        void SaveAuthor( Author author);
        void UpdateAuthor(Author author);
    }
}
