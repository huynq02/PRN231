﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.DAO
{
    public class BookDAO
    {
        private static BookDAO instance = null;
        private static readonly object instanceLock = new();

        public static BookDAO Instance
        {
            get
            {
                lock (instanceLock)
                {
                    if (instance == null)
                    {
                        instance = new BookDAO();
                    }
                }
                return instance;
            }
        }

        public static List<Book> GetBooks()
        {
            List<Book> books;
            try
            {
                var context = new BookStoreContext();

                books = context.Books.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return books;
        }

        public static Book FindBookById(int id)
        {
            var book = new Book();
            try
            {
                var context = new BookStoreContext();

                book = context.Books.AsNoTracking().FirstOrDefault(e => e.BookId == id);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return book;
        }

        public static void SaveBook(Book book)
        {
            try
            {
                var context = new BookStoreContext();

                context.Books.Add(book);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdateBook(Book book)
        {
            try
            {
                var context = new BookStoreContext();

                context.Entry(book).State = EntityState.Modified;
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteBook(Book book)
        {
            try
            {
                var context = new BookStoreContext();

                var c = context.Books.SingleOrDefault(e => e.BookId.Equals(book.BookId));
                if (c != null)
                {
                    context.Books.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
