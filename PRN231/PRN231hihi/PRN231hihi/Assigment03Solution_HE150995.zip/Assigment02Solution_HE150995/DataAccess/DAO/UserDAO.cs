﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.DAO
{
    public class UserDAO
    {
        private static UserDAO _instance = null;
        private static readonly object _instanceLock = new();

        public static UserDAO Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {
                        _instance = new UserDAO();
                    }
                }
                return _instance;
            }
        }

        public static List<User> GetUsers()
        {
            List<User> users;
            try
            {
                var context = new BookStoreContext();
                users = context.Users.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return users;
        }

        public static async Task<User?> Login(string emailAddress, string password)
        {
            User user = new();
            try
            {
                BookStoreContext context = new();
                user =  await context.Users.AsNoTracking().Include(e => e.Role).FirstOrDefaultAsync(e => e.EmailAddress.Equals(emailAddress) && e.Password.Equals(password));
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return user;
        }

        public static async Task<User?> FindUserById(int id)
        {
            var user = new User();
            try
            {
                var context = new BookStoreContext();
                user = await context.Users.AsNoTracking().Include(e => e.Role).FirstOrDefaultAsync(e => e.UserId == id);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return user;
        }

        public static void SaveUser(User user)
        {
            try
            {
                var context = new BookStoreContext();
                context.Users.Add(user);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdateUser(User user)
        {
            try
            {
                var context = new BookStoreContext();
                context.Users.Update(user);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteUser(User user)
        {
            try
            {
                var context = new BookStoreContext();
                var c = context.Users.SingleOrDefault(e => e.UserId.Equals(user.UserId));
                if (c != null)
                {
                    context.Users.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
