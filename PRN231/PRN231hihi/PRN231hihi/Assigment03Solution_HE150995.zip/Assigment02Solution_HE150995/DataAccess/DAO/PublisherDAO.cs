﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.DAO
{
    public class PublisherDAO
    {
        private static PublisherDAO _instance = null;
        private static readonly object _instanceLock = new();

        public static PublisherDAO Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {
                        _instance = new PublisherDAO();
                    }
                }
                return _instance;
            }
        }

        public static List<Publisher> GetPublishers()
        {
            List<Publisher> publishers;
            try
            {
                var context = new BookStoreContext();

                publishers = context.Publishers.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return publishers;
        }

        public static Publisher FindPublisherById(int id)
        {
            var publisher = new Publisher();
            try
            {
                var context = new BookStoreContext();

                publisher = context.Publishers.AsNoTracking().FirstOrDefault(e => e.PubId == id);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return publisher;
        }

        public static void SavePublisher(Publisher publisher)
        {
            try
            {
                var context = new BookStoreContext();

                context.Publishers.Add(publisher);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdatePublisher(Publisher publisher)
        {
            try
            {
                var context = new BookStoreContext();

                context.Entry(publisher).State = EntityState.Modified;
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeletePublisher(Publisher publisher)
        {
            try
            {
                var context = new BookStoreContext();

                var c = context.Publishers.SingleOrDefault(e => e.PubId.Equals(publisher.PubId));
                if (c != null)
                {
                    context.Publishers.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
