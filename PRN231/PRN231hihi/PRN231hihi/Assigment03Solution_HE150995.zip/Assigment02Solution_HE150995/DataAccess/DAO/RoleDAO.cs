﻿using BusinessObjects.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DataAccess.DAO
{
    public class RoleDAO
    {
        private static RoleDAO _instance = null;
        private static readonly object _instanceLock = new();

        public static RoleDAO Instance
        {
            get
            {
                lock (_instanceLock)
                {
                    if (_instance == null)
                    {
                        _instance = new RoleDAO();
                    }
                }
                return _instance;
            }
        }

        public static List<Role> GetRoles()
        {
            List<Role> roles;
            try
            {
                var context = new BookStoreContext();

                roles = context.Roles.AsNoTracking().ToList();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return roles;
        }

        public static Role FindRoleById(int id)
        {
            var role = new Role();
            try
            {
                var context = new BookStoreContext();

                role = context.Roles.AsNoTracking().FirstOrDefault(e => e.RoleId == id);

            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
            return role;
        }

        public static void SaveRole(Role role)
        {
            try
            {
                var context = new BookStoreContext();

                context.Roles.Add(role);
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void UpdateRole(Role role)
        {
            try
            {
                var context = new BookStoreContext();

                context.Entry(role).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        public static void DeleteRole( Role role)
        {
            try
            {
                var context = new BookStoreContext();

                var c = context.Roles.SingleOrDefault(e => e.RoleId.Equals(role.RoleId));
                if (c != null)
                {
                    context.Roles.Remove(c);
                }
                context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}
