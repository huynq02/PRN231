﻿using AutoMapper;
using BusinessObjects.Dtos;
using BusinessObjects.Models;
using DataAccess.IRepository;
using DataAccess.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Formatter;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.AspNetCore.OData.Routing.Controllers;

namespace eBookStoreWebAPI.Controllers
{

    public class AuthorsController : ODataController
    {
        private readonly BookStoreContext _dbContext;
        private readonly IAuthorRepository _authorRepository;
        private readonly IMapper _mapper;

        public AuthorsController(BookStoreContext dbContext, IAuthorRepository authorRepository, IMapper mapper)
        {
            _dbContext = dbContext;
            _authorRepository = authorRepository;
            dbContext.ChangeTracker.QueryTrackingBehavior = Microsoft.EntityFrameworkCore.QueryTrackingBehavior.NoTracking;
            _mapper = mapper;
        }

        [HttpGet]
        [EnableQuery(PageSize = 10)]
        [Authorize]
        public IActionResult GetAuthors()
        {
            var Authors = _authorRepository.GetAuthors();
            return Ok(Authors);
        }
        [HttpPost]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Post([FromBody] AuthorDto AuthorDto)
        {
            var Author = _mapper.Map<Author>(AuthorDto);
            _authorRepository.SaveAuthor(Author);
            return Created(Author);
        }
        [HttpPut]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Put([FromODataUri] int key, [FromBody] AuthorDto AuthorDto)
        {
            var existedAuthor = _authorRepository.FindAuthorById(key);
            if (existedAuthor == null)
            {
                return NotFound();
            }
            var Author = _mapper.Map<Author>(AuthorDto);
            _authorRepository.UpdateAuthor(Author);
            return Ok();
        }

        [HttpDelete]
        [EnableQuery]
        [Authorize(Roles = "admin")]
        public IActionResult Delete([FromODataUri] int key)
        {
            var Author = _authorRepository.FindAuthorById(key);
            if (Author == null)
            {
                return NotFound();
            }
            _authorRepository.DeleteAuthor(Author);
            return Ok();
        }
    }
}
