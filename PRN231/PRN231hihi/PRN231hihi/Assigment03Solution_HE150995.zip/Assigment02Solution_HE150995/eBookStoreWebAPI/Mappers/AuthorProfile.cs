﻿using AutoMapper;
using BusinessObjects.Dtos;
using BusinessObjects.Models;

namespace eBookStoreWebAPI.Mappers
{
    
        public class AuthorProfile : Profile
        {
            public AuthorProfile()
            {
                CreateMap<AuthorDto, Author>();
                CreateMap<Author, AuthorDto>();
            }

        }
}
