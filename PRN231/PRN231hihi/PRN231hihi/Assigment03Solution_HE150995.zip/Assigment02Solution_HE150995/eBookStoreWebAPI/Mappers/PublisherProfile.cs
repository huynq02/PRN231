﻿using AutoMapper;
using BusinessObjects.Dtos;
using BusinessObjects.Models;

namespace eBookStoreWebAPI.Mappers
{
    
        public class PublisherProfile : Profile
        {
            public PublisherProfile()
            {
                CreateMap<PublisherDto, Publisher>();
                CreateMap<Publisher, PublisherDto>();
            }

        }
}
