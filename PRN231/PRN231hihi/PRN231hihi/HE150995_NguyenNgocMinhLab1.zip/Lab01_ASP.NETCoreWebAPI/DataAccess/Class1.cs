﻿namespace DataAccess
{
    public class Class1
    {

    }
}