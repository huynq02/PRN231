﻿namespace Entity
{
    public enum Category
    {
        Book,
        Magazine,
        EBook
    }
}
